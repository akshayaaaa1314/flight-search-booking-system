# SkyBook — Flight Search & Booking System

A full-stack flight-search and seat-booking application built with Flask, MySQL, SQLAlchemy, and vanilla HTML/CSS/JavaScript. It includes an API-driven search flow, real-time seat availability, booking history, and cancellation.

## Features
- Search flights by source, destination, and travel date
- View available and booked seats; select multiple seats
- Create a confirmed booking with a unique database booking ID
- Search booking history by email or retrieve a booking by its ID
- Cancel eligible bookings and release seats
- Validates required data and returns useful JSON errors
- Uses database row locks when booking seats to reduce double-booking under concurrent requests

## Project structure
```text
backend/       Flask API, models, configuration, seed script
frontend/      HTML, CSS, JavaScript client
database/      MySQL database creation script
```

## Setup

### 1. Prerequisites
- Python 3.10+
- MySQL 8+
- A MySQL user with permission to create/use the `flight_booking` database

### 2. Create database
```bash
mysql -u root -p < database/schema.sql
```

### 3. Configure the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r ../requirements.txt
cp .env.example .env  # Windows PowerShell: Copy-Item .env.example .env
```
Edit `.env` with your MySQL username/password. Do not commit `.env`.

### 4. Seed data and run
```bash
python seed.py
python app.py
```
Open `http://127.0.0.1:5000`. The seed data uses future sample dates in October 2026; search exactly with the routes/dates listed below.

## Sample searches
| Source | Destination | Date |
|---|---|---|
| Hyderabad | Delhi | 2026-10-10 |
| Hyderabad | Mumbai | 2026-10-10 |
| Mumbai | Goa | 2026-10-12 |
| Hyderabad | Chennai | 2026-10-14 |

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/flights/search?source=Hyderabad&destination=Delhi&date=2026-10-10` | Search flights |
| GET | `/api/flights/{flight_id}/seats` | Flight and seat map |
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings/{booking_id}` | Get booking by ID |
| GET | `/api/bookings?email=name@example.com` | Booking history by email |
| PATCH | `/api/bookings/{booking_id}/cancel` | Cancel booking |

### Create booking payload
```json
{"flight_id": 1, "passenger_name": "Akshaya Panuganti", "email": "akshaya@example.com", "phone": "9876543210", "seat_numbers": ["1A", "1B"]}
```

## Resume description
**SkyBook | Flask, MySQL, SQLAlchemy, JavaScript** — Built a full-stack flight-search and booking platform with REST APIs, interactive multi-seat selection, booking history, and cancellation. Implemented transactional seat locking and input validation to prevent conflicting reservations.

## Git hygiene
Copy `backend/.env.example` to `backend/.env`, then add the supplied `.gitignore`; never commit credentials.
