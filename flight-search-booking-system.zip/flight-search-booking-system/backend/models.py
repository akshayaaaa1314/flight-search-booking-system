from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
class Flight(db.Model):
    __tablename__ = 'flights'
    flight_id = db.Column(db.Integer, primary_key=True)
    airline = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(80), nullable=False, index=True)
    destination = db.Column(db.String(80), nullable=False, index=True)
    departure_time = db.Column(db.DateTime, nullable=False, index=True)
    arrival_time = db.Column(db.DateTime, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    total_seats = db.Column(db.Integer, nullable=False)
    seats = db.relationship('Seat', backref='flight', lazy=True, cascade='all, delete-orphan')
    bookings = db.relationship('Booking', backref='flight', lazy=True)
    def to_dict(self, include_seats=False):
        available = sum(1 for s in self.seats if not s.is_booked)
        data = {'flight_id': self.flight_id, 'airline': self.airline, 'source': self.source, 'destination': self.destination, 'departure_time': self.departure_time.isoformat(), 'arrival_time': self.arrival_time.isoformat(), 'price': float(self.price), 'total_seats': self.total_seats, 'available_seats': available}
        if include_seats: data['seats'] = [s.to_dict() for s in self.seats]
        return data
class Seat(db.Model):
    __tablename__ = 'seats'
    seat_id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flights.flight_id'), nullable=False, index=True)
    seat_number = db.Column(db.String(8), nullable=False)
    is_booked = db.Column(db.Boolean, nullable=False, default=False)
    __table_args__ = (db.UniqueConstraint('flight_id', 'seat_number', name='uq_flight_seat'),)
    def to_dict(self): return {'seat_id': self.seat_id, 'seat_number': self.seat_number, 'is_booked': self.is_booked}
class Booking(db.Model):
    __tablename__ = 'bookings'
    booking_id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flights.flight_id'), nullable=False)
    passenger_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, index=True)
    phone = db.Column(db.String(30), nullable=False)
    seat_numbers = db.Column(db.String(255), nullable=False)
    booking_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False, default='CONFIRMED')
    def to_dict(self, include_flight=False):
        data={'booking_id': self.booking_id, 'flight_id': self.flight_id, 'passenger_name': self.passenger_name, 'email': self.email, 'phone': self.phone, 'seat_numbers': self.seat_numbers.split(','), 'booking_date': self.booking_date.isoformat(), 'status': self.status}
        if include_flight: data['flight'] = self.flight.to_dict()
        return data
