from datetime import datetime
from app import create_app
from models import db, Flight, Seat
flights = [
('IndiGo','Hyderabad','Delhi','2026-10-10 06:30','2026-10-10 08:45',6200),('Air India','Hyderabad','Delhi','2026-10-10 13:15','2026-10-10 15:30',7100),('Vistara','Hyderabad','Mumbai','2026-10-10 08:10','2026-10-10 09:35',4900),('IndiGo','Hyderabad','Mumbai','2026-10-10 18:20','2026-10-10 19:45',5200),('Air India','Delhi','Bengaluru','2026-10-11 07:00','2026-10-11 09:40',6800),('IndiGo','Delhi','Bengaluru','2026-10-11 16:30','2026-10-11 19:10',6400),('Akasa Air','Mumbai','Goa','2026-10-12 09:00','2026-10-12 10:20',3900),('IndiGo','Mumbai','Goa','2026-10-12 17:40','2026-10-12 19:00',4100),('Vistara','Bengaluru','Chennai','2026-10-13 06:45','2026-10-13 07:50',3200),('Air India','Bengaluru','Chennai','2026-10-13 15:30','2026-10-13 16:35',3500),('IndiGo','Hyderabad','Chennai','2026-10-14 10:20','2026-10-14 11:35',3800),('Akasa Air','Hyderabad','Chennai','2026-10-14 19:15','2026-10-14 20:30',4000)]
app=create_app()
with app.app_context():
    db.create_all()
    if Flight.query.first(): print('Database already contains flights.'); raise SystemExit
    for airline,src,dst,dep,arr,price in flights:
        flight=Flight(airline=airline,source=src,destination=dst,departure_time=datetime.strptime(dep,'%Y-%m-%d %H:%M'),arrival_time=datetime.strptime(arr,'%Y-%m-%d %H:%M'),price=price,total_seats=24)
        db.session.add(flight); db.session.flush()
        for row in 'ABCDEF':
            for number in range(1,5): db.session.add(Seat(flight_id=flight.flight_id,seat_number=f'{number}{row}'))
    db.session.commit(); print(f'Seeded {len(flights)} flights and {len(flights)*24} seats.')
