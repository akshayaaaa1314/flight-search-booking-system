from datetime import date, datetime
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from models import db, Flight, Seat, Booking

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')

def create_app():
    app = Flask(__name__, static_folder=str(BASE_DIR.parent / 'frontend'), static_url_path='')
    app.config.from_object('config.Config')
    db.init_app(app)
    CORS(app)

    @app.get('/')
    def index():
        return send_from_directory(app.static_folder, 'index.html')

    @app.get('/api/health')
    def health():
        return jsonify({'message': 'Flight Booking API is running'})

    @app.get('/api/flights/search')
    def search_flights():
        source = request.args.get('source', '').strip()
        destination = request.args.get('destination', '').strip()
        travel_date = request.args.get('date', '').strip()
        if not source or not destination or not travel_date:
            return jsonify({'error': 'source, destination and date are required'}), 400
        if source.lower() == destination.lower():
            return jsonify({'error': 'Source and destination must be different'}), 400
        try:
            parsed_date = datetime.strptime(travel_date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'date must use YYYY-MM-DD format'}), 400
        flights = (Flight.query.filter(func.lower(Flight.source) == source.lower(),
                    func.lower(Flight.destination) == destination.lower(),
                    func.date(Flight.departure_time) == parsed_date)
                   .order_by(Flight.departure_time).all())
        return jsonify({'flights': [f.to_dict(include_seats=True) for f in flights]})

    @app.get('/api/flights/<int:flight_id>/seats')
    def get_seats(flight_id):
        flight = db.session.get(Flight, flight_id)
        if not flight:
            return jsonify({'error': 'Flight not found'}), 404
        return jsonify({'flight': flight.to_dict(), 'seats': [s.to_dict() for s in flight.seats]})

    @app.post('/api/bookings')
    def create_booking():
        data = request.get_json(silent=True) or {}
        required = ['flight_id', 'passenger_name', 'email', 'phone', 'seat_numbers']
        missing = [field for field in required if not data.get(field)]
        if missing:
            return jsonify({'error': f"Missing required fields: {', '.join(missing)}"}), 400
        if not isinstance(data['seat_numbers'], list) or not data['seat_numbers']:
            return jsonify({'error': 'seat_numbers must be a non-empty array'}), 400
        clean_seats = sorted(set(str(x).strip().upper() for x in data['seat_numbers']))
        if len(clean_seats) != len(data['seat_numbers']):
            return jsonify({'error': 'Seat numbers must be unique'}), 400
        email = str(data['email']).strip().lower()
        if '@' not in email or '.' not in email.rsplit('@', 1)[-1]:
            return jsonify({'error': 'Enter a valid email address'}), 400
        try:
            flight = db.session.get(Flight, int(data['flight_id']))
            if not flight:
                return jsonify({'error': 'Flight not found'}), 404
            if flight.departure_time <= datetime.now():
                return jsonify({'error': 'This flight is no longer available for booking'}), 400
            seats = (Seat.query.filter(Seat.flight_id == flight.flight_id, Seat.seat_number.in_(clean_seats))
                     .with_for_update().all())
            if len(seats) != len(clean_seats):
                db.session.rollback()
                return jsonify({'error': 'One or more selected seats do not exist'}), 400
            unavailable = [s.seat_number for s in seats if s.is_booked]
            if unavailable:
                db.session.rollback()
                return jsonify({'error': 'Seats are no longer available', 'unavailable_seats': unavailable}), 409
            for seat in seats:
                seat.is_booked = True
            booking = Booking(flight_id=flight.flight_id, passenger_name=str(data['passenger_name']).strip(),
                email=email, phone=str(data['phone']).strip(), seat_numbers=','.join(clean_seats), status='CONFIRMED')
            db.session.add(booking)
            db.session.commit()
            return jsonify({'message': 'Booking confirmed', 'booking': booking.to_dict(include_flight=True)}), 201
        except (ValueError, TypeError):
            return jsonify({'error': 'flight_id must be a valid number'}), 400
        except SQLAlchemyError:
            db.session.rollback()
            return jsonify({'error': 'Unable to create booking. Please try again.'}), 500

    @app.get('/api/bookings/<int:booking_id>')
    def get_booking(booking_id):
        booking = db.session.get(Booking, booking_id)
        if not booking:
            return jsonify({'error': 'Booking not found'}), 404
        return jsonify({'booking': booking.to_dict(include_flight=True)})

    @app.get('/api/bookings')
    def booking_history():
        email = request.args.get('email', '').strip().lower()
        if not email:
            return jsonify({'error': 'email query parameter is required'}), 400
        bookings = Booking.query.filter_by(email=email).order_by(Booking.booking_date.desc()).all()
        return jsonify({'bookings': [b.to_dict(include_flight=True) for b in bookings]})

    @app.patch('/api/bookings/<int:booking_id>/cancel')
    def cancel_booking(booking_id):
        try:
            booking = Booking.query.filter_by(booking_id=booking_id).with_for_update().first()
            if not booking:
                return jsonify({'error': 'Booking not found'}), 404
            if booking.status == 'CANCELLED':
                return jsonify({'error': 'Booking is already cancelled'}), 400
            if booking.flight.departure_time <= datetime.now():
                return jsonify({'error': 'Cannot cancel a departed flight'}), 400
            numbers = booking.seat_numbers.split(',')
            Seat.query.filter(Seat.flight_id == booking.flight_id, Seat.seat_number.in_(numbers)).update({Seat.is_booked: False}, synchronize_session=False)
            booking.status = 'CANCELLED'
            db.session.commit()
            return jsonify({'message': 'Booking cancelled', 'booking': booking.to_dict(include_flight=True)})
        except SQLAlchemyError:
            db.session.rollback()
            return jsonify({'error': 'Unable to cancel booking. Please try again.'}), 500

    @app.errorhandler(404)
    def not_found(_): return jsonify({'error': 'Resource not found'}), 404
    @app.errorhandler(405)
    def method_not_allowed(_): return jsonify({'error': 'Method not allowed'}), 405
    return app

if __name__ == '__main__':
    app = create_app()
    with app.app_context(): db.create_all()
    app.run(debug=True)
