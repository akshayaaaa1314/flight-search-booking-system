CREATE DATABASE IF NOT EXISTS flight_booking;
USE flight_booking;
-- Tables are created by Flask-SQLAlchemy on first application start.
-- Then run: python seed.py
